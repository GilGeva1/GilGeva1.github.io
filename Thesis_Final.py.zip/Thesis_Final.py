#!/usr/bin/env python
# coding: utf-8

# # Installation

# In[1]:


from sklearn.metrics import confusion_matrix, accuracy_score, roc_auc_score, roc_curve
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import RFE

from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split

import numpy as np
import librosa
import matplotlib.pyplot as plt
import librosa.display as ld
import tensorflow as tf
import librosa.display as dsp
import keras
import datetime, os
import cv2
import scipy
import sys
import glob
import pickle
import math

from scipy.signal import correlate

from IPython.display import Audio

from PIL import Image

from IPython.display import display

from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix,ConfusionMatrixDisplay,f1_score
from sklearn.model_selection import train_test_split

from keras.models import Sequential, Model, clone_model
from keras.layers import Input, Dense, Bidirectional, LSTM, Dropout, Activation, GRU
from keras.layers import Conv2D, concatenate, MaxPooling2D, Flatten, Embedding, Lambda
from keras import backend as K
from keras.callbacks import ModelCheckpoint, TensorBoard, ReduceLROnPlateau, TerminateOnNaN
from keras import backend as K
from keras import regularizers
from keras.layers import BatchNormalization as BatchNorm
from tensorflow.keras import layers
from tensorflow.keras.layers import Rescaling
from keras.utils import plot_model

from tensorflow.keras.utils import plot_model
from tensorflow.keras.losses import MeanSquaredError
from tensorflow.python.ops.numpy_ops import np_config
np_config.enable_numpy_behavior()

from os.path import isfile

from tensorflow.keras.optimizers import RMSprop

from tensorflow import keras

from scipy.io import wavfile

from numpy.linalg import svd

from scipy.stats.mstats import gmean

from matplotlib import rcParams

from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

sr = 44100


# # Helper Functions

# In[2]:


def show_summary_stats(history):
    # List all data in history
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.plot(history.history['root_mean_squared_error'])
    plt.plot(history.history['val_root_mean_squared_error'])
    plt.title('model loss')
    plt.ylabel('mean squared error')
    plt.xlabel('epoch')
    plt.legend(['loss', 'val_loss', 'root_mean_squared_error', 'val_root_mean_squared_error', 'MyCustomMetric', 'val_MyCustomMetric'], loc='upper left')
    plt.ylim(0, 1.0)
    plt.show()


def my_loss_fn(y_true, y_pred, dtype=None):

    # euclidean_distance
    euclidean_distance = tf.norm(y_true - y_pred, ord='euclidean', axis=1)

    # angular_error
    y_true_normalized = tf.nn.l2_normalize(y_true, axis=-1)
    y_pred_normalized = tf.nn.l2_normalize(y_pred, axis=-1)
    dot_product = tf.reduce_sum(y_true_normalized * y_pred_normalized, axis=-1)
    angular_error = (tf.acos(tf.clip_by_value(dot_product, -1.0 + 1e-7, 1.0 - 1e-7)) * 180) / np.pi

    return euclidean_distance + angular_error

def deg2rad(angle):
    return angle / 180 * np.pi

def rad2deg(angle):
    return angle * 180 / np.pi

def transpose_layer(x):
    return np.transpose(x, (0, 2, 1))

class MyCustomMetric(tf.keras.metrics.Metric):
    def __init__(self, name='my_custom_metric', **kwargs):
        super(MyCustomMetric, self).__init__(name=name, **kwargs)
        self.loss_sum = self.add_weight(name='loss_sum', initializer='zeros')
        self.num_samples = self.add_weight(name='num_samples', initializer='zeros')

    def update_state(self, y_true, y_pred, sample_weight=None):
        loss = my_loss_fn(y_true, y_pred)

        self.loss_sum.assign_add(tf.reduce_sum(loss))
        if sample_weight is not None:
            self.num_samples.assign_add(tf.reduce_sum(sample_weight))
        else:
            self.num_samples.assign_add(tf.cast(tf.shape(loss)[0], tf.float32))

    def result(self):
        return self.loss_sum / self.num_samples

    def reset_state(self):
        self.loss_sum.assign(0.0)
        self.num_samples.assign(0.0)

class EuclideanDistanceMetric(tf.keras.metrics.Metric):
    def __init__(self, name='euclidean_distance', **kwargs):
        super().__init__(name='euclidean', **kwargs)
        self.euclidean_distance = self.add_weight(name="ed", initializer="zeros")
        self.total_samples = self.add_weight(name="total_samples", initializer="zeros")


    def update_state(self, y_true, y_pred, sample_weight=None):
        diff = y_true - y_pred
        euclidean_distance = tf.norm(diff, ord='euclidean', axis=1)
        e_avg = tf.reduce_mean(euclidean_distance)
        self.euclidean_distance.assign_add(tf.reduce_sum(euclidean_distance))
        self.total_samples.assign_add(tf.cast(tf.shape(y_true)[0], dtype=tf.float32))

    def result(self):
        return self.euclidean_distance / self.total_samples

class AngularErrorMetric(tf.keras.metrics.Metric):
    def __init__(self, name='angular_error', **kwargs):
        super().__init__(name='angular', **kwargs)
        self.angular_error = self.add_weight(name="ae", initializer="zeros")
        self.total_samples = self.add_weight(name="total_samples", initializer="zeros")

    def update_state(self, y_true, y_pred, sample_weight=None):
        y_true_normalized = tf.nn.l2_normalize(y_true, axis=-1)
        y_pred_normalized = tf.nn.l2_normalize(y_pred, axis=-1)
        dot_product = tf.reduce_sum(y_true_normalized * y_pred_normalized, axis=-1)
        angular_error = tf.acos(tf.clip_by_value(dot_product, -1.0 + 1e-7, 1.0 - 1e-7)) * 180 / np.pi
        self.angular_error.assign_add(tf.reduce_sum(angular_error))
        self.total_samples.assign_add(tf.cast(tf.shape(y_true)[0], dtype=tf.float32))

    def result(self):
        return self.angular_error / self.total_samples


# In[3]:


# Performance presentation

def performance_presentation(model_present, test_x, test_y, sig_test_x=None, parts_per_recording = 20, history = 'none'):
    mse = MeanSquaredError()
    speaker_names = []
    means = []
    num_inst = []
    ang = []
    f_speaker_names = []
    f_means = []
    f_num_inst = []
    f_ang = []
    f_rang = []
    example_number = 5

    # Calculate RMSE and angular error
    for i in range(1,len(labels)+1):
        y_tmp = labels[i]
        
        if sig_test_x is not None:
            x_tmp = test_x[np.where(np.all(test_y[:,1:] == labels[i], axis=1))][:,:,:,1:]
            sig_tmp = sig_test_x[np.where(np.all(test_y[:,1:] == labels[i], axis=1))][:,1:,:]
            y_tag_tmp = model_present.predict([x_tmp, sig_tmp], verbose=0)

        elif len(test_x.shape) == 4:
            x_tmp = test_x[np.where(np.all(test_y[:,1:] == labels[i], axis=1))][:,:,:,1:]
            y_tag_tmp = model_present.predict(x_tmp, verbose=0)

        else:
            x_tmp = test_x[np.where(np.all(test_y[:,1:] == labels[i], axis=1))][:,1:,:]
            y_tag_tmp = model_present.predict(x_tmp, verbose=0)
        
        globals()["num_inst" + str(i)] = x_tmp.shape[0]

        # RMSE
        euclidean_distance = tf.norm(y_tmp - y_tag_tmp, ord='euclidean', axis=1)
        globals()["mean_rmse" + str(i)] = np.mean(euclidean_distance)

        # Angular error
        y_normalized = tf.nn.l2_normalize(y_tmp, axis=-1)
        y_tag_normalized = tf.nn.l2_normalize(y_tag_tmp, axis=-1)
        dot_product = tf.reduce_sum(y_normalized * y_tag_normalized, axis=-1)
        angular_error = (tf.acos(tf.clip_by_value(dot_product, -1.0 + 1e-7, 1.0 - 1e-7)) * 180) / np.pi
        globals()["ang" + str(i)] = np.mean(angular_error).numpy()

        speaker_names.append(str(i))
        num_inst.append(globals()["num_inst"+str(i)])
        means.append(globals()["mean_rmse"+str(i)])
        ang.append(globals()["ang"+str(i)])
    
    fig, ax = plt.subplots()
    bar = ax.bar(np.arange(len(labels)), means, align='center', alpha=0.5, ecolor='black', capsize=10)
    # ax.bar_label(bar, labels=num_inst)
    ax.set_ylabel('Mean Euclidean distance')
    ax.set_xlabel('Speaker number')
    ax.set_xticks(np.arange(len(labels)))
    ax.set_xticklabels(speaker_names)
    ax.set_title('Mean Euclidean distance by speaker')
    ax.yaxis.grid(True)
    plt.tight_layout()
    plt.show()
    plt.show()

    print("Mean Euclidean distance", np.mean(means))

    fig, ax = plt.subplots()
    bar = ax.bar(np.arange(len(labels)), ang, align='center', alpha=0.5, ecolor='black', capsize=10)
    # ax.bar_label(bar, labels=num_inst)
    ax.set_ylabel('Mean angular error')
    ax.set_xlabel('Speaker number')
    ax.set_xticks(np.arange(len(labels)))
    ax.set_xticklabels(speaker_names)
    ax.set_title('Mean angular error by speaker')
    ax.yaxis.grid(True)
    plt.tight_layout()
    plt.show()
    plt.show()
    
    print("Mean angular error", np.mean(ang))

    error_values = np.array(ang)

    x = [coords[0] for coords in labels.values()]
    y = [coords[1] for coords in labels.values()]
    z = [coords[2] for coords in labels.values()]
    
    norm = Normalize(vmin=error_values.min(), vmax=error_values.max())

    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')
    sc = ax.scatter(x, y, z, c=error_values, cmap='RdYlGn_r', s=100, alpha=1.0)
    cbar = plt.colorbar(sc, shrink=0.4)
    cbar.set_label('Angular error (deg)')
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.view_init(elev=10., azim=0, roll=0)
    
    cone = Poly3DCollection([[[-1, 0, 0], [0, 1, 0], [1, 0, 0]]], color='black')
    ax.add_collection3d(cone)
    
    plt.show()

    freq = np.zeros((test_x.shape[0]))
    
    if sig_test_x is not None:
        for i in range(test_x.shape[0]):
            mag = plt.magnitude_spectrum(sig_test_x[i,:,0],Fs=44100)
            max_mag = np.argmax(mag[0])
            argmax_mag = mag[1][np.argmax(mag[0])]
            freq[i] = argmax_mag
    
    elif len(test_x.shape) == 4:
        for i in range(test_x.shape[0]):
            mag = plt.magnitude_spectrum(combined_signal_X_test[i,:,0],Fs=44100)
            max_mag = np.argmax(mag[0])
            argmax_mag = mag[1][np.argmax(mag[0])]
            freq[i] = argmax_mag
    
    else:
        for i in range(test_x.shape[0]):
            mag = plt.magnitude_spectrum(test_x[i,:,0],Fs=44100)
            max_mag = np.argmax(mag[0])
            argmax_mag = mag[1][np.argmax(mag[0])]
            freq[i] = argmax_mag

    ranges = [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000, np.max(freq)]
    ranges_label = [.1, .2, .3, .4, .5, .6, .7, .8, .9, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 'max']

    for i in range(len(ranges)-1):
        y_tmp = test_y[np.where((freq >= ranges[i]) & (freq <= ranges[i+1]))][:,1:]
        if y_tmp.shape[0]!=0:
            
            if sig_test_x is not None:
                x_tmp = test_x[np.where((freq >= ranges[i]) & (freq <= ranges[i+1]))][:,:,:,1:]
                sig_tmp = sig_test_x[np.where((freq >= ranges[i]) & (freq <= ranges[i+1]))][:,1:,:]    
                y_tag_tmp = model_present.predict([x_tmp, sig_tmp], verbose=0)
        
            elif len(test_x.shape) == 4:
                x_tmp = test_x[np.where((freq >= ranges[i]) & (freq <= ranges[i+1]))][:,:,:,1:]
                y_tag_tmp = model_present.predict(x_tmp, verbose=0)
        
            else:
                x_tmp = test_x[np.where((freq >= ranges[i]) & (freq <= ranges[i+1]))][:,1:,:]  
                y_tag_tmp = model_present.predict(x_tmp, verbose=0)

    
            globals()["f_num_inst" + str(i)] = x_tmp.shape[0]
            
            # RMSE
            euclidean_distance = tf.norm(y_tmp - y_tag_tmp, ord='euclidean', axis=1)
            globals()["f_mean_rmse" + str(i)] = np.mean(euclidean_distance)    
            
            # Angular error
            y_normalized = tf.nn.l2_normalize(y_tmp, axis=-1)
            y_tag_normalized = tf.nn.l2_normalize(y_tag_tmp, axis=-1)
            dot_product = tf.reduce_sum(y_normalized * y_tag_normalized, axis=-1)
            angular_error = (tf.acos(tf.clip_by_value(dot_product, -1.0 + 1e-7, 1.0 - 1e-7)) * 180) / np.pi
            globals()["f_ang" + str(i)] = np.mean(angular_error).numpy()

            f_rang.append(str(i))
            f_num_inst.append(globals()["f_num_inst"+str(i)])
            f_means.append(globals()["f_mean_rmse"+str(i)])
            f_ang.append(globals()["f_ang"+str(i)])
        
        else:
            f_rang.append(str(i))
            f_num_inst.append(0)
            f_means.append(0)
            f_ang.append(0)
    
    fig, ax = plt.subplots()
    bar = ax.bar(np.arange(len(ranges)-1), f_means, align='center', alpha=0.5, ecolor='black', capsize=10)
    # ax.bar_label(bar, labels=f_num_inst)
    ax.set_ylabel('Mean Euclidean distance')
    ax.set_xlabel('Frequency range')
    ax.set_xticks(np.arange(len(ranges)-1))
    ax.set_xticklabels(ranges_label)
    ax.set_title('Mean Euclidean distance for frequency range')
    ax.yaxis.grid(True)
    plt.tight_layout()
    plt.show()
    plt.show()

    fig, ax = plt.subplots()
    bar = ax.bar(np.arange(len(ranges)-1), f_ang, align='center', alpha=0.5, ecolor='black', capsize=10)
    # ax.bar_label(bar, labels=f_num_inst)
    ax.set_ylabel('Mean angular error')
    ax.set_xlabel('Frequency range')
    ax.set_xticks(np.arange(len(ranges)-1))
    ax.set_xticklabels(ranges_label)
    ax.set_title('Mean angular error for frequency range')
    ax.yaxis.grid(True)
    plt.tight_layout()
    plt.show()
    plt.show()
    
    # 3D plot

    y_plot=[]
    y_tag=[]
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    
    for i in range(10):
        rnd = np.random.randint(test_y.shape[0])
        if sig_test_x is not None:
            globals()["y_tag" + str(i)] = model_present([np.expand_dims(test_x[rnd][:,:,1:], axis=(0, -1)),np.expand_dims(sig_test_x[rnd][1:,:], axis=(0, -1))]).numpy()[0]
        elif len(test_x.shape) == 4:
            globals()["y_tag" + str(i)] = model_present(np.expand_dims(test_x[rnd][:,:,1:], axis=(0, -1))).numpy()[0]
        else:
            globals()["y_tag" + str(i)] = model_present(np.expand_dims(test_x[rnd][1:,:], axis=(0, -1))).numpy()[0]

        globals()["y_plot" + str(i)] = test_y[rnd]
        y_plot.append(globals()["y_plot" + str(i)])
        y_tag.append(globals()["y_tag" + str(i)])
        ax.scatter(y_plot[i][1], y_plot[i][2], y_plot[i][3], marker='x', facecolor ='black')
        ax.scatter(y_tag[i][0], y_tag[i][1], y_tag[i][2], s=2, facecolor ='red')
        ax.text(y_plot[i][1], y_plot[i][2], y_plot[i][3], str(i), color='black')
        # ax.text(y_tag[i][0], y_tag[i][1], y_tag[i][2], str(i), color='red')
    plt.show()

    model_present.summary()
    return error_values


# In[5]:


labels = {
    1 : (0.000000, 2.63992, -0.230963),
    2 : (1.69691, 2.02229, -0.230963),
    3 : (2.59981, 0.458417, -0.230963),
    4 : (2.28623, -1.31996, -0.230963),
    5 : (0.902904, -2.48071, -0.230963),
    6 : (-0.902904, -2.48071, -0.230963),
    7 : (-2.28623, -1.31996, -0.230963),
    8 : (-2.59981, 0.458417, -0.230963),
    9 : (-1.69691, 2.02229, -0.230963),
    10 : (0.833069, 2.28884, 1.18799),
    11 : (2.10941, 1.21787, 1.18799),
    12 : (2.39873, -0.42296, 1.18799),
    13 : (1.56566, -1.86588, 1.18799),
    14 : (0.000000, -2.43573, 1.18799),
    15 : (-1.56566, -1.86588, 1.18799),
    16 : (-2.39873, -0.42296, 1.18799),
    17 : (-2.10941, 1.21787, 1.18799),
    18 : (-0.833069, 2.28884, 1.18799),
    19 : (0.000000, 1.52499, 2.34828),
    20 : (1.45035, 0.471248, 2.34828),
    21 : (0.896366, -1.23374, 2.34828),
    22 : (-0.896366, -1.23374, 2.34828),
    23 : (-1.45035, 0.471248, 2.34828),
    24 : (-0.000000, -0.000000, 2.44)
    }


# In[81]:


# Splitting the recording to mini records at length - part_length_in_seconds

def cut_wav_array(audio_array, sample_rate, cut_start, cut_end, cut_duration, part_length_in_seconds=0.25):

    # Cutting the edges
    start_index = int(sample_rate * cut_start)
    end_index = len(audio_array[start_index:]) - (len(audio_array[start_index:]) % int(sample_rate * cut_duration))
    cut_array = audio_array[:end_index]

    # Reshape cut array into parts
    num_parts = int(len(cut_array) / (sample_rate * cut_duration))
    parts_array = np.reshape(cut_array, (num_parts, int(sample_rate * cut_duration)))

    parts = []
    tmp = np.zeros(1000)
    for i, part in enumerate(parts_array):
        cut_part=part[int(cut_start*sample_rate):int(cut_end*sample_rate)]
        length = int(part_length_in_seconds*sample_rate)
        for j in range(int(cut_part.shape[0]/length)):
            tmp = cut_part[j*length:(j+1)*length]
            parts.append((j, tmp))

    return [part[1] for part in parts], int(cut_part.shape[0]/length)


# In[72]:


# Creating spectogram array

def creating_data(left_parts_array, right_parts_array, speaker, labels = labels):

    left_tmp=[]
    right_tmp=[]
    tmp = []
    for i in range(len(left_parts_array)):
        left_tmp.append(librosa.amplitude_to_db(np.abs(librosa.stft(left_parts_array[i],n_fft=256,hop_length = 64))))
        right_tmp.append(librosa.amplitude_to_db(np.abs(librosa.stft(right_parts_array[i],n_fft=256,hop_length = 64))))
        tmp.append(np.stack((left_tmp[i], right_tmp[i]), axis=2))

    left_X = np.stack(left_tmp)
    right_X = np.stack(right_tmp)
    X = np.stack(tmp)
    index_column = np.arange(len(left_parts_array)).reshape(-1,1,1)
    X = np.insert(X, 0, index_column, axis=-1)

# Creating y arrays

    values = labels[speaker]
    y = np.tile(values, (len(left_parts_array), 1))
    index_column = np.arange(len(left_parts_array))
    y = np.insert(y, 0, index_column, axis=1)

# Creating waveform array

    signal_tmp = []
    for i in range(len(left_parts_array)):
        signal_tmp.append(np.stack([left_parts_array[i], right_parts_array[i]],axis = 1))

    signal_left_X = np.stack(left_parts_array)
    signal_right_X = np.stack(right_parts_array)
    signal_X = np.stack(signal_tmp, axis = 0)

    index_column = np.arange(len(left_parts_array)).reshape(-1, 1)
    signal_X = np.insert(signal_X, 0, index_column, axis=1)
    return X, signal_X, y


# In[73]:


convolved_train = ["BigTroubles - Phantom.stem"]

convolved_test = ["Meaxic - Take A Step.stem"]

# convolved_train = ["BigTroubles - Phantom.stem", "Bill Chudziak - Children Of No-one.stem", "Black Bloc - If You Want Success.stem", "Celestial Shore - Die For Us.stem",
#                    "Chris Durban - Celebrate.stem", "Clara Berry And Wooldog - Air Traffic.stem", "Clara Berry And Wooldog - Stella.stem", "Clara Berry And Wooldog - Waltz For My Victims.stem",
#                    "Cnoc An Tursa - Bannockburn.stem", "Creepoid - OldTree.stem", "Dark Ride - Burning Bridges.stem", "Dreamers Of The Ghetto - Heavy Love.stem",
#                    "Drumtracks - Ghost Bitch.stem", "Faces On Film - Waiting For Ga.stem", "Fergessen - Back From The Start.stem", "Fergessen - Nos Palpitants.stem",
#                    "Fergessen - The Wind.stem", "Flags - 54.stem", "Giselle - Moss.stem", "Grants - PunchDrunk.stem", "Helado Negro - Mitad Del Mundo.stem",
#                    "Hezekiah Jones - Borrowed Heart.stem", "Hollow Ground - Left Blind.stem", "Hop Along - Sister Cities.stem", "Invisible Familiars - Disturbing Wildlife.stem",
#                    "James May - All Souls Moon.stem", "James May - Dont Let Go.stem", "James May - If You Say.stem", "James May - On The Line.stem", "Jay Menon - Through My Eyes.stem",
#                    "Johnny Lokke - Promises & Lies.stem", "Johnny Lokke - Whisper To A Scream.stem", "Jokers, Jacks & Kings - Sea Of Leaves.stem", "Leaf - Come Around.stem", "Leaf - Summerghost.stem",
#                    "Leaf - Wicked.stem", "Lushlife - Toynbee Suite.stem", "Matthew Entwistle - Dont You Ever.stem", "Meaxic - Take A Step.stem", "Meaxic - You Listen.stem", "Music Delta - 80s Rock.stem",
#                    "Music Delta - Beatles.stem", "Music Delta - Britpop.stem", "Music Delta - Country1.stem", "Music Delta - Country2.stem", "Music Delta - Disco.stem", "Music Delta - Gospel.stem",
#                    "Music Delta - Grunge.stem", "Music Delta - Hendrix.stem", "Music Delta - Punk.stem", "Music Delta - Reggae.stem", "Music Delta - Rock", "Music Delta - Rockabilly", "Night Panther - Fire.stem",
#                    "North To Alaska - All The Same.stem", "Patrick Talbot - A Reason To Leave.stem", "Patrick Talbot - Set Me Free.stem", "Phre The Eon - Everybody's Falling Apart.stem", "Port St Willow - Stay Even.stem",
#                    "Remember December - C U Next Time.stem", "Secret Mountains - High Horse.stem", "Skelpolu - Human Mistakes.stem", "Skelpolu - Together Alone.stem", "Snowmine - Curfews.stem", "Spike Mullings - Mike's Sulking.stem",
#                    "St Vitus - Word Gets Around.stem", "Steven Clark - Bounty.stem", "Strand Of Oaks - Spacestation.stem", "Sweet Lights - You Let Me Down.stem", "Swinging Steaks - Lost My Way.stem", "The Districts - Vermont.stem",
#                    "The Long Wait - Back Home To Blue.stem", "The Scarlet Brand - Les Fleurs Du Mal.stem", "The So So Glos - Emergency.stem", "The Wrong'Uns - Rothko.stem", "Tim Taler - Stalker.stem", "Titanium - Haunted Age.stem",
#                    "Traffic Experiment - Once More (With Feeling).stem", "Traffic Experiment - Sirens.stem", "Triviul - Angelsaint.stem", "Triviul - Dorothy.stem", "Voelund - Comfort Lives In Belief.stem", "Wall Of Death - Femme.stem",
#                    "Young Griffo - Blood To Bone.stem", "Young Griffo - Facade.stem", "Young Griffo - Pennies.stem"]

# convolved_test = ["Al James - Schoolboy Facination.stem", "AM Contra - Heart Peripheral.stem", "Angels In Amplifiers - I'm Alright.stem", "Arise - Run Run Run.stem",
#                   "BKS - Bulldozer.stem", "BKS - Too Much.stem", "Bobby Nobody - Stitch Up.stem", "Buitraker - Revo X.stem", "Carlos Gonzalez - A Place For Us.stem",
#                   "Cristina Vane - So Easy.stem", "Detsky Sad - Walkie Talkie.stem", "Enda Reilly - Cur An Long Ag Seol.stem", "Forkupines - Semantics.stem", 
#                   "Georgia Wonder - Siren.stem", "Girls Under Glass - We Feel Alright.stem", "Hollow Ground - Ill Fate.stem", "Juliet's Rescue - Heartbeats.stem", "Little Chicago's Finest - My Own.stem",
#                   "Louis Cressy Band - Good Time.stem", "Lyndsey Ollard - Catching Up.stem", "M.E.R.C. Music - Knockout.stem", "Moosmusic - Big Dummy Shake.stem",
#                   "Motor Tapes - Shore.stem", "Mu - Too Bright.stem", "Nerve 9 - Pray For The Rain.stem", "PR - Happy Daze.stem", "PR - Oh No.stem", "Punkdisco - Oral Hygiene.stem"]


# # Data proccesing

# In[1]:


part_length_in_seconds=0.25
cut_start=0
cut_end=part_length_in_seconds
cut_duration=part_length_in_seconds
num_songs = 1
start_with = 0

sample_rate=48000
cut_start=2.5
cut_end=4.5
cut_duration=6
part_length_in_seconds=0.25

for j in range(start_with,start_with + num_songs):
    for i in range(1,25):
        globals()["left_song" + str(j) + "_dir" + str(i)] = librosa.load("convolved_train/" + convolved_train[j] + "_" + str(i) + "lconv.wav", sr=sr)[0][1000000:-2000000]
        globals()["right_song" + str(j) + "_dir" + str(i)] = librosa.load("convolved_train/" + convolved_train[j] + "_" + str(i) + "rconv.wav", sr=sr)[0][1000000:-2000000]
        globals()["left_parts" + str(j) + "_dir" + str(i)] = cut_wav_array(globals()["left_song" + str(j) + "_dir" + str(i)], sr, 0, left_song0_dir1.shape[0], 0.25, 0.25)
        globals()["right_parts" + str(j) + "_dir" + str(i)] = cut_wav_array(globals()["right_song" + str(j) + "_dir" + str(i)], sr, 0, right_song0_dir1.shape[0], 0.25, 0.25)

        globals()["test_left_song" + str(j) + "_dir" + str(i)] = librosa.load("convolved_test/" + convolved_test[j] + "_" + str(i) + "lconv.wav", sr=sr)[0][1000000:-2000000]
        globals()["test_right_song" + str(j) + "_dir" + str(i)] = librosa.load("convolved_test/" + convolved_test[j] + "_" + str(i) + "rconv.wav", sr=sr)[0][1000000:-2000000]
        globals()["test_left_parts" + str(j) + "_dir" + str(i)] = cut_wav_array(globals()["test_left_song" + str(j) + "_dir" + str(i)], sr, 0, test_left_song0_dir1.shape[0],0.25, 0.25)
        globals()["test_right_parts" + str(j) + "_dir" + str(i)] = cut_wav_array(globals()["test_right_song" + str(j) + "_dir" + str(i)], sr,0, test_right_song0_dir1.shape[0],0.25, 0.25)

for i in range(1,25):
    globals()["left_parts_dir" + str(i)] = globals()["left_parts" + str(start_with) + "_dir" + str(i)]
    globals()["right_parts_dir" + str(i)] = globals()["right_parts" + str(start_with) + "_dir" + str(i)]
    globals()["test_left_parts_dir" + str(i)] = globals()["test_left_parts" + str(start_with) + "_dir" + str(i)]
    globals()["test_right_parts_dir" + str(i)] = globals()["test_right_parts" + str(start_with) + "_dir" + str(i)]
    for j in range(start_with + 1,start_with + num_songs):
        globals()["left_parts_dir" + str(i)] = np.concatenate((globals()["left_parts_dir" + str(i)], globals()["left_parts" + str(j) + "_dir" + str(i)]))
        globals()["right_parts_dir" + str(i)] = np.concatenate((globals()["right_parts_dir" + str(i)], globals()["right_parts" + str(j) + "_dir" + str(i)]))
        globals()["test_left_parts_dir" + str(i)] = np.concatenate((globals()["test_left_parts_dir" + str(i)], globals()["test_left_parts" + str(j) + "_dir" + str(i)]))
        globals()["test_right_parts_dir" + str(i)] = np.concatenate((globals()["test_right_parts_dir" + str(i)], globals()["test_right_parts" + str(j) + "_dir" + str(i)]))


# In[134]:


# Reducing cize of data

for i in range(1,25):
    globals()["new_left_parts_dir" + str(i)], __, globals()["new_right_parts_dir" + str(i)], __ = train_test_split(globals()["left_parts_dir" + str(i)], globals()["right_parts_dir" + str(i)], test_size=0.75, random_state=42)
    globals()["new_test_left_parts_dir" + str(i)], __, globals()["new_test_right_parts_dir" + str(i)], __ = train_test_split(globals()["test_left_parts_dir" + str(i)], globals()["test_right_parts_dir" + str(i)], test_size=0.87, random_state=42)


# In[2]:


# Creating data arrays for model

data_dict = {}
X, signal_X, y = creating_data(globals()["new_left_parts_dir" + str(1)], globals()["new_left_parts_dir" + str(1)], 1)

combined_X = np.empty((0, X.shape[1], X.shape[2], X.shape[3]))
combined_signal_X = np.empty((0, signal_X.shape[1], signal_X.shape[2]))
combined_y = np.empty((0, y.shape[1]))
combined_X_test = np.empty((0, X.shape[1], X.shape[2], X.shape[3]))
combined_signal_X_test = np.empty((0, signal_X.shape[1], signal_X.shape[2]))
combined_y_test = np.empty((0, y.shape[1]))

for i in range(1, 25):
    print(i)
    X, signal_X, y = creating_data(globals()["new_left_parts_dir" + str(i)], globals()["new_right_parts_dir" + str(i)], i)
    X_test, signal_X_test, y_test = creating_data(globals()["new_test_left_parts_dir" + str(i)], globals()["new_test_right_parts_dir" + str(i)], i)
    combined_X = np.vstack((combined_X, X))
    combined_signal_X = np.vstack((combined_signal_X, signal_X))
    combined_y = np.vstack((combined_y, y))
    combined_X_test = np.vstack((combined_X_test, X_test))
    combined_signal_X_test = np.vstack((combined_signal_X_test, signal_X_test))
    combined_y_test = np.vstack((combined_y_test, y_test))


# In[136]:


# Printing np.size

size_in_bytes = combined_X.nbytes
size_in_gb = size_in_bytes / (1024 ** 3)
print(f"Size of the array: {size_in_gb:.2f} GB")


# # Loading Data

# In[21]:


# Loading 0.05 np.arrays

combined_X = np.load('processed_data/combined_X_005.npy')
combined_X_test = np.load('processed_data/combined_X_005_test.npy')
combined_signal_X = np.load('processed_data/combined_signal_X_005.npy')
combined_signal_X_test = np.load('processed_data/combined_signal_X_005_test.npy')
combined_y = np.load('processed_data/combined_y_005.npy')
combined_y_test = np.load('processed_data/combined_y_005_test.npy')


# In[11]:


# Loading 0.25 np.arrays

combined_X = np.load('processed_data/combined_X_025.npy')
combined_signal_X = np.load('processed_data/combined_signal_X_025.npy')
combined_y = np.load('processed_data/combined_y_025.npy')
combined_X_test = np.load('processed_data/combined_X_025_test.npy')
combined_signal_X_test = np.load('processed_data/combined_signal_X_025_test.npy')
combined_y_test = np.load('processed_data/combined_y_025_test.npy')


# In[137]:


# Creating hybrid data-sets

con_dataset = tf.data.Dataset.zip((tf.data.Dataset.from_tensor_slices((combined_X[:,:,:,1:], combined_signal_X[:,1:,:])), tf.data.Dataset.from_tensor_slices(combined_y[:,1:]))).batch(128)
con_val_dataset = tf.data.Dataset.zip((tf.data.Dataset.from_tensor_slices((combined_X_test[:,:,:,1:], combined_signal_X_test[:,1:,:])), tf.data.Dataset.from_tensor_slices(combined_y_test[:,1:]))).batch(128)


# In[138]:


# Creating spectrogram data-sets

spec_dataset = tf.data.Dataset.from_tensor_slices((combined_X[:,:,:,1:], combined_y[:,1:])).batch(128)
spec_val_dataset = tf.data.Dataset.from_tensor_slices((combined_X_test[:,:,:,1:], combined_y_test[:,1:])).batch(128)


# In[139]:


# Creating waveform data-sets

waveform_dataset = tf.data.Dataset.from_tensor_slices((combined_signal_X[:,1:,:], combined_y[:,1:])).batch(128)
waveform_val_dataset = tf.data.Dataset.from_tensor_slices((combined_signal_X_test[:,1:,:], combined_y_test[:,1:])).batch(128)


# In[22]:


# Creating one-ear data-sets

combined_X1 = combined_X[:,:,:,:2]
combined_X_test1 = combined_X_test[:,:,:,:2]
combined_signal_X1 = combined_signal_X[:,:,:1]
combined_signal_X_test1 = combined_signal_X_test[:,:,:1]

con_dataset = tf.data.Dataset.zip((tf.data.Dataset.from_tensor_slices((combined_X1[:,:,:,1:], combined_signal_X1[:,1:,:])), tf.data.Dataset.from_tensor_slices(combined_y[:,1:]))).batch(128)
con_val_dataset = tf.data.Dataset.zip((tf.data.Dataset.from_tensor_slices((combined_X_test1[:,:,:,1:], combined_signal_X_test1[:,1:,:])), tf.data.Dataset.from_tensor_slices(combined_y_test[:,1:]))).batch(128)


# In[17]:


# Creating Benchmark data-sets

waveform_dataset = tf.data.Dataset.from_tensor_slices((transpose_layer(combined_signal_X)[:,:,1:], combined_y[:,1:])).batch(128)
waveform_val_dataset = tf.data.Dataset.from_tensor_slices((transpose_layer(combined_signal_X_test)[:,:,1:], combined_y_test[:,1:])).batch(128)


# # Final 005 results

# ## Hybrid

# In[55]:


hybrid_model = tf.keras.models.load_model("savrd_hrtf_models/hybrid_finally1.keras", custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(hybrid_model, combined_X_test, combined_y_test, combined_signal_X_test)


# ## Waveform

# In[53]:


hybrid_model = tf.keras.models.load_model("savrd_hrtf_models/wav_005.keras", custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(hybrid_model, combined_signal_X_test, combined_y_test)


# ## Spectrogram

# In[57]:


hybrid_model = tf.keras.models.load_model("savrd_hrtf_models/spec_0051.keras", custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(hybrid_model, combined_X_test, combined_y_test)


# ## One ear

# In[59]:


hybrid_model = tf.keras.models.load_model("savrd_hrtf_models/one_ear_11.keras", custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(hybrid_model, combined_X_test[:,:,:,:2], combined_y_test, combined_signal_X_test[:,:,:1])


# ## Benchmark

# In[62]:


benchmark_model = tf.keras.models.load_model("savrd_hrtf_models/model_benchmark_final12.keras", custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation_benchmark(benchmark_model, transpose_layer(combined_signal_X_test[:,1:,:]), combined_y_test)


# # Final 025 seconds results

# ## Hybrid

# In[7]:


hybrid_model = tf.keras.models.load_model("thesis_models/hybrid_model_025.keras", custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})


# ## Spectrogram

# In[8]:


spectrogram_model = tf.keras.models.load_model('thesis_models/spectrogram_model_025.keras', custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(spectrogram_model, combined_X_test, combined_y_test)


# ## Waveform

# In[15]:


wavform_model = tf.keras.models.load_model('thesis_models/waveform_model_025.keras', custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(wavform_model, combined_signal_X_test, combined_y_test)


# ## One-ear

# In[17]:


one_ear_model = tf.keras.models.load_model('thesis_models/one_ear_model_005.keras', custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

performance_presentation(one_ear_model, combined_X_test[:,:,:,:2], combined_y_test, combined_signal_X_test[:,:,:1])


# ## Benchmark

# In[59]:


benchmark_model = tf.keras.models.load_model('thesis_models/benchmark_model_025.keras', custom_objects={
    'MyCustomMetric': MyCustomMetric,
    'EuclideanDistanceMetric': EuclideanDistanceMetric,
    'AngularErrorMetric': AngularErrorMetric,
    'my_loss_fn': my_loss_fn
})

b_values = performance_presentation_benchmark(benchmark_model, transpose_layer(combined_signal_X_test[:,1:,:]), combined_y_test)


# In[151]:


x = theta_array
y1 = h_values
y2 = b_values

fig, axs = plt.subplots(1, 2, figsize=(10, 5))

axs[0].bar(x, y1, color="tab:blue", width=4)
axs[0].set(title="Hybrid model", xlabel="θ", ylabel="Angular error")

axs[1].bar(x, y2, color="tab:red", width=4)
axs[1].set(title="Benchmark model", xlabel="θ", ylabel="Angular error")

plt.tight_layout()
plt.show()


# # Training

# ## Hybrid model

# In[3]:


inputs = keras.Input(shape=combined_signal_X[0,1:,:].shape)
x = layers.Conv1D(filters=63, kernel_size=75, activation="relu")(inputs)
x = layers.Conv1D(filters=59, kernel_size=91, activation="tanh")(x)
x = layers.Conv1D(filters=58, kernel_size=96, activation="tanh")(x)
x = layers.MaxPooling1D(pool_size=10)(x)
x = Flatten()(x)
x = Dense(161, activation = 'sigmoid')(x)
x = Dense(178, activation = 'tanh')(x)
outputs = Dense(3, activation = 'linear', name='preds')(x)
model_wave_hybrid = keras.Model(inputs=inputs, outputs=outputs)

inputs = keras.Input(shape=combined_X[:,:,:,1:][0].shape)
x = layers.Conv2D(filters=25, kernel_size=(4,4), activation="relu")(inputs)
# Remark next line if 0.05
x = layers.MaxPooling2D(pool_size=(3, 3))(x)
x = layers.Conv2D(filters=25, kernel_size=(5, 5), activation="relu")(x)
x = layers.MaxPooling2D(pool_size=(3, 3))(x)
x = layers.Conv2D(filters=40, kernel_size=(4, 4), activation="relu")(x)
x = Flatten()(x)
x = Dense(255, activation = 'relu')(x)
x = Dropout(0.5)(x)
x = Dense(124, activation = 'relu')(x)
x = Dropout(0.5)(x)
x = Dense(148, activation = 'relu')(x)
outputs = Dense(3, activation = 'linear', name='preds')(x)
model_spec_hybrid = keras.Model(inputs=inputs, outputs=outputs)

model_spec_hybrid = tf.keras.Model(inputs=model_spec_hybrid.input, outputs=model_spec_hybrid.layers[-2].output)
model_spec_hybrid._name = 'model_spec'
model_wave_hybrid = tf.keras.Model(inputs=model_wave_hybrid.input, outputs=model_wave_hybrid.layers[-2].output)
model_wave_hybrid._name = 'model_wave'

input_shape1 = (model_spec_hybrid.input_shape[1:])
input_shape2 = (model_wave_hybrid.input_shape[1:])

input_data1 = Input(input_shape1)
input_data2 = Input(input_shape2)

output1 = model_spec_hybrid(input_data1)
output2 = model_wave_hybrid(input_data2)

combined_output = concatenate([output1, output2])

dense_layer_1 = Dense(units=1024, activation='relu', name='dense_layer_1')(combined_output)
dense_layer_2 = Dense(units=128, activation='relu', name='dense_layer_2')(dense_layer_1)
dense_layer = Dense(units=3, activation='linear', name='dense_layer_3')
regression_output = dense_layer(dense_layer_2)

hybrid_model = Model(inputs=[input_data1, input_data2], outputs=regression_output)

hybrid_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
        loss=my_loss_fn,
        metrics=[MyCustomMetric(name="my_loss"),EuclideanDistanceMetric(name="euclidean"), AngularErrorMetric(name="ang")])

callbacks = [ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=3, min_delta=0.001, verbose=1, min_lr=0.0000000001)]

hybrid_model_history = hybrid_model.fit(con_dataset, epochs=100, callbacks=callbacks, validation_data=con_val_dataset)


# ## spectrogram model

# In[4]:


inputs = keras.Input(shape=combined_X[:,:,:,1:][0].shape)
x = layers.Conv2D(filters=25, kernel_size=(4,4), activation="relu")(inputs)
# Remark next line if 0.05
x = layers.MaxPooling2D(pool_size=(3, 3))(x)
x = layers.Conv2D(filters=25, kernel_size=(5, 5), activation="relu")(x)
x = layers.MaxPooling2D(pool_size=(3, 3))(x)
x = layers.Conv2D(filters=40, kernel_size=(4, 4), activation="relu")(x)
x = Flatten()(x)
x = Dense(255, activation = 'relu')(x)
x = Dropout(0.5)(x)
x = Dense(124, activation = 'relu')(x)
x = Dropout(0.5)(x)
x = Dense(148, activation = 'relu')(x)
outputs = Dense(3, activation = 'linear', name='preds')(x)

spec_model = tf.keras.Model(inputs=inputs, outputs=outputs)

spec_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                   loss=my_loss_fn,
                   metrics=[MyCustomMetric(name="my_loss"),EuclideanDistanceMetric(name="euclidean"), AngularErrorMetric(name="ang")])

callbacks = [ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=5, min_delta=0.0001, verbose=1, min_lr=0.000000001)]

spec_model_history = spec_model.fit(spec_dataset, epochs=200, callbacks=callbacks, validation_data=spec_val_dataset)


# ## waveform model

# In[5]:


inputs = keras.Input(shape=combined_signal_X[0,1:,:].shape)
x = layers.Conv1D(filters=63, kernel_size=75, activation="relu")(inputs)
x = layers.Conv1D(filters=59, kernel_size=91, activation="tanh")(x)
x = layers.Conv1D(filters=58, kernel_size=96, activation="tanh")(x)
x = layers.MaxPooling1D(pool_size=10)(x)
x = Flatten()(x)
x = Dense(161, activation = 'sigmoid')(x)
x = Dense(178, activation = 'tanh')(x)
outputs = Dense(3, activation = 'linear', name='preds')(x)

wav_model = tf.keras.Model(inputs=inputs, outputs=outputs)

wav_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
                  loss=my_loss_fn,
                  metrics=[MyCustomMetric(name="my_loss"),EuclideanDistanceMetric(name="euclidean"), AngularErrorMetric(name="ang")])

callbacks = [
    ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=3, min_delta=0.01, verbose=1, min_lr=0.00000001),
]

spec_ang_history = wav_model.fit(waveform_dataset, epochs=100, callbacks=callbacks, validation_data=waveform_val_dataset)


# ## one ear model

# In[6]:


inputs = keras.Input(shape=combined_signal_X1[0,1:,:].shape)
x = layers.Conv1D(filters=63, kernel_size=75, activation="relu")(inputs)
x = layers.Conv1D(filters=59, kernel_size=91, activation="tanh")(x)
x = layers.Conv1D(filters=58, kernel_size=96, activation="tanh")(x)
x = layers.MaxPooling1D(pool_size=10)(x)
x = Flatten()(x)
x = Dense(161, activation = 'sigmoid')(x)
x = Dense(178, activation = 'tanh')(x)
outputs = Dense(3, activation = 'linear', name='preds')(x)
model_wave_hybrid = keras.Model(inputs=inputs, outputs=outputs)

inputs = keras.Input(shape=combined_X1[:,:,:,1:][0].shape)
x = layers.Conv2D(filters=25, kernel_size=(4,4), activation="relu")(inputs)
# Remark next line if 0.05
# x = layers.MaxPooling2D(pool_size=(3, 3))(x)
x = layers.Conv2D(filters=25, kernel_size=(5, 5), activation="relu")(x)
x = layers.MaxPooling2D(pool_size=(3, 3))(x)
x = layers.Conv2D(filters=40, kernel_size=(4, 4), activation="relu")(x)
x = Flatten()(x)
x = Dense(255, activation = 'relu')(x)
x = Dropout(0.5)(x)
x = Dense(124, activation = 'relu')(x)
x = Dropout(0.5)(x)
x = Dense(148, activation = 'relu')(x)
outputs = Dense(3, activation = 'linear', name='preds')(x)
model_spec_hybrid = keras.Model(inputs=inputs, outputs=outputs)

model_spec_hybrid = tf.keras.Model(inputs=model_spec_hybrid.input, outputs=model_spec_hybrid.layers[-2].output)
model_spec_hybrid._name = 'model_spec'
model_wave_hybrid = tf.keras.Model(inputs=model_wave_hybrid.input, outputs=model_wave_hybrid.layers[-2].output)
model_wave_hybrid._name = 'model_wave'

input_shape1 = (model_spec_hybrid.input_shape[1:])
input_shape2 = (model_wave_hybrid.input_shape[1:])

input_data1 = Input(input_shape1)
input_data2 = Input(input_shape2)

output1 = model_spec_hybrid(input_data1)
output2 = model_wave_hybrid(input_data2)

combined_output = concatenate([output1, output2])

dense_layer_1 = Dense(units=1024, activation='relu', name='dense_layer_1')(combined_output)
dense_layer_2 = Dense(units=128, activation='relu', name='dense_layer_2')(dense_layer_1)
dense_layer = Dense(units=3, activation='linear', name='dense_layer_3')
regression_output = dense_layer(dense_layer_2)

hybrid_model = Model(inputs=[input_data1, input_data2], outputs=regression_output)

hybrid_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001),
        loss=my_loss_fn,
        metrics=[MyCustomMetric(name="my_loss"),EuclideanDistanceMetric(name="euclidean"), AngularErrorMetric(name="ang")])

callbacks = [ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=3, min_delta=0.0001, verbose=1, min_lr=0.0000000001)]

hybrid_model_history = hybrid_model.fit(con_dataset, epochs=200, callbacks=callbacks, validation_data=con_val_dataset)


# ## benchmark model

# In[19]:


inputs = keras.Input(shape=transpose_layer(combined_signal_X)[0,:,1:].shape)
x = tf.keras.layers.Lambda(lambda x: tf.split(x, 2, axis=1))(inputs)
x1 = layers.Conv1D(filters=64, kernel_size=256, activation="linear", padding="same")(x[0])
x2 = layers.Conv1D(filters=64, kernel_size=256, activation="linear", padding="same")(x[1])
x1 = tf.keras.layers.MaxPooling1D(pool_size=2, padding="same")(x1)
x2 = tf.keras.layers.MaxPooling1D(pool_size=2, padding="same")(x2)
x = tf.keras.layers.Concatenate(axis=1)([x1, x2])
x = layers.Conv1D(filters=64, kernel_size=18, activation="relu", padding="same")(x)
x = layers.MaxPooling1D(pool_size=4, padding="same")(x)
x = layers.Conv1D(filters=64, kernel_size=6, activation="relu", padding="same")(x)
x = layers.MaxPooling1D(pool_size=4, padding="same")(x)
x = layers.Flatten()(x)
x = layers.Dense(1024, activation='relu')(x)
x = layers.Dense(1024, activation='relu')(x)
outputs = layers.Dense(3, activation='linear', name='preds')(x)

benchmark_model = keras.Model(inputs=inputs, outputs=outputs)

benchmark_model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
                     loss = tf.keras.losses.MeanSquaredError(),
                     metrics=[tf.keras.metrics.RootMeanSquaredError(name="rmse"),
                              EuclideanDistanceMetric(name="dist"),
                              AngularErrorMetric(name="ang")])

callbacks = [ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience=4, min_delta=0.01, verbose=1, min_lr=0.000000001)]

benchmark_model_history = benchmark_model.fit(waveform_dataset, epochs=150, callbacks=callbacks, validation_data=waveform_val_dataset)


# # Data visualisation
# 

# In[19]:


Audio(data=combined_signal_X[1004][1:,1],rate=sr)


# In[27]:


fig, ax = plt.subplots(nrows=1, ncols=1, sharex=True)
D = librosa.amplitude_to_db(np.abs(librosa.stft(combined_signal_X[23][1:,1])), ref=np.max)
img = librosa.display.specshow(D, y_axis='linear', x_axis='time', sr=sr, ax=ax)
ax.set(title='Spectrogram')
ax.label_outer()
hop_length = 64
ax.set_xlabel('Time (s)')
ax.set_ylabel('Frequency (Hz)')
fig.colorbar(img, ax=ax, format="%+2.f dB")
fig.show()


# In[21]:


# Looking at the amplitude of every frequency
re = plt.magnitude_spectrum(combined_signal_X[23][1:,0],Fs=sr)
plt.xlim(0, 3000)
ax.set_xlabel('Grequency (Hz)')
plt.grid(True)
max_mag = np.argmax(re[0])
argmax_mag = re[1][np.argmax(re[0])]


# In[23]:


fig, (ax) = plt.subplots(sharex=True)
librosa.display.waveshow(combined_signal_X[23][1:,0], sr=sr, ax=ax)
ax.label_outer()

